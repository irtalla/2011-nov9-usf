package com.revature.services;

public class GradeServiceImpl implements GradeService {
//	GradeDAO

}
