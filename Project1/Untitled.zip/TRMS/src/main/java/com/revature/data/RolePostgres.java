package com.revature.data;

public class RolePostgres {

}
