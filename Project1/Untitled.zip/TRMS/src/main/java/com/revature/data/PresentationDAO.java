package com.revature.data;

import com.revature.beans.Presentation;

public interface PresentationDAO extends GenericDAO <Presentation> {

}
