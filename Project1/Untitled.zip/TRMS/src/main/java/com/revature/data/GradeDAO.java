package com.revature.data;

import com.revature.beans.Grade;

public interface GradeDAO extends GenericDAO<Grade>{

}
