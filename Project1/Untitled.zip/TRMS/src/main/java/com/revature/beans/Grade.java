package com.revature.beans;

public class Grade {
	private Integer id; 

}
